Klassenkassa

Klassenkassa ist eine Verwaltungssoftware.
Projektbeschreibung

Eine Verwaltungsapp, wo man eine Klassenkassa verwalten kann. Es werden am Anfang alle Kategorien angezeigt. Wenn man eine Bezahlung auswählt, dann werden alle beteiligten Schüler angezeigt mit Daten wie Name, Katalognummer, Schulden, Bezahlstatus und zusätzlichen Daten angezeigt. Dies wird mit einer Datenbank verwaltet.
Repository Aufbau
